import React from 'react';
import Box from '../../components/Box';

// Create PriceSummary user interface
const PriceSummary = ({ summary, totalPrice }) => (
  <Box width={['290px', '450px']}>
    <p>REPLACE ME!</p>
  </Box>
);

export default PriceSummary;
